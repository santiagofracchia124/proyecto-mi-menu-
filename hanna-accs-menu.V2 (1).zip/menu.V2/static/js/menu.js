(function () {
  let MENU = { categorias: {} };
  let catActualKey = null;
  let subActualKey = null;

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }

  function fmtPrecio(n) {
    return '$' + Number(n).toLocaleString('es-AR');
  }

  function stockBadgeHtml(stock) {
    if (stock === undefined || stock === null) return '';
    stock = Number(stock);
    if (stock <= 0) return '<span class="stock-badge out">Sin stock</span>';
    if (stock <= 3) return '<span class="stock-badge low">Quedan ' + stock + '</span>';
    return '<span class="stock-badge ok">' + stock + ' disponibles</span>';
  }

  function primerSubcatConItems(cat) {
    const keys = Object.keys(cat.subcategorias || {});
    for (const k of keys) {
      if ((cat.subcategorias[k].items || []).length > 0) return k;
    }
    return keys[0] || null;
  }

  function renderSidebar() {
    const nav = document.getElementById('sidebar-nav');
    const catKeys = Object.keys(MENU.categorias);
    if (catKeys.length === 0) {
      nav.innerHTML = '<p style="font-size:0.82rem;color:var(--muted);padding:0 0.6rem;">Sin categorías todavía.</p>';
      return;
    }
    nav.innerHTML = catKeys.map(function (catKey) {
      const cat = MENU.categorias[catKey];
      const subKeys = Object.keys(cat.subcategorias || {});
      const isOpen = catKey === catActualKey;
      return (
        '<button type="button" class="cat-btn' + (isOpen ? ' active' : '') + '" data-cat="' + catKey + '">' +
          '<span class="cat-icon">' + (cat.emoji || '✷') + '</span>' + escapeHtml(cat.nombre) +
        '</button>' +
        '<div class="subcat-group' + (isOpen ? ' open' : '') + '" data-catgroup="' + catKey + '">' +
          subKeys.map(function (subKey) {
            const sub = cat.subcategorias[subKey];
            const activeSub = catKey === catActualKey && subKey === subActualKey;
            return '<button type="button" class="subcat-btn' + (activeSub ? ' active' : '') + '" data-cat="' + catKey + '" data-sub="' + subKey + '">' + escapeHtml(sub.nombre) + '</button>';
          }).join('') +
        '</div>'
      );
    }).join('');

    nav.querySelectorAll('.cat-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        const catKey = btn.dataset.cat;
        if (catActualKey === catKey) {
          catActualKey = null; subActualKey = null;
        } else {
          catActualKey = catKey;
          subActualKey = primerSubcatConItems(MENU.categorias[catKey]);
        }
        renderSidebar();
        renderItems();
      });
    });
    nav.querySelectorAll('.subcat-btn').forEach(function (btn) {
      btn.addEventListener('click', function () {
        catActualKey = btn.dataset.cat;
        subActualKey = btn.dataset.sub;
        renderSidebar();
        renderItems();
      });
    });
  }

  function renderItems() {
    const grid = document.getElementById('items-grid');
    const title = document.querySelector('.section-title');
    const count = document.getElementById('section-count');

    if (!catActualKey || !subActualKey) {
      title.textContent = 'Elegí una categoría';
      count.textContent = '';
      grid.innerHTML = '<div class="empty-state"><p>Elegí una categoría del costado para ver los productos ✷</p></div>';
      return;
    }

    const cat = MENU.categorias[catActualKey];
    const sub = cat.subcategorias[subActualKey];
    const items = sub.items || [];

    title.textContent = sub.nombre;
    count.textContent = items.length + ' producto' + (items.length !== 1 ? 's' : '');

    if (items.length === 0) {
      grid.innerHTML = '<div class="empty-state"><p>No hay productos cargados en esta sección todavía.</p></div>';
      return;
    }

    grid.innerHTML = items.map(function (it) {
      const sinStock = it.stock !== undefined && Number(it.stock) <= 0;
      const imgHtml = it.imagen
        ? '<div class="item-emoji item-imagen" style="background-image:url(\'' + it.imagen + '\')"></div>'
        : '<div class="item-emoji"></div>';
      return (
        '<div class="item-card' + (sinStock ? ' sin-stock' : '') + '">' +
          imgHtml +
          '<div class="item-body">' +
            '<div class="item-name">' + escapeHtml(it.nombre) + '</div>' +
            (it.desc ? '<div class="item-desc">' + escapeHtml(it.desc) + '</div>' : '') +
            '<div class="item-footer">' +
              '<span class="item-precio">' + fmtPrecio(it.precio) + '</span>' +
              stockBadgeHtml(it.stock) +
            '</div>' +
          '</div>' +
        '</div>'
      );
    }).join('');
  }

  function init() {
    const dataEl = document.getElementById('menu-data');
    if (!dataEl) return;
    try {
      MENU = JSON.parse(dataEl.textContent);
    } catch (e) {
      MENU = { categorias: {} };
    }
    const primeraCat = Object.keys(MENU.categorias)[0] || null;
    if (primeraCat) {
      catActualKey = primeraCat;
      subActualKey = primerSubcatConItems(MENU.categorias[primeraCat]);
    }
    renderSidebar();
    renderItems();
  }

  document.addEventListener('DOMContentLoaded', init);
})();
